
public abstract class FormaGeometrica {
    public abstract double getPerimetro();
}
